import './header.css';
import React from 'react';
import './autoriz.css'

function Autoriz() {
  return (
    <div className="container">
      <div className="auth-box">
        <h2>Авторизация</h2>
        <form>
          <div className="input-group">
            <label htmlFor="login">Логин</label>
            <input type="text" id="login" name="login" />
          </div>
          <div className="input-group">
            <label htmlFor="password">Пароль</label>
            <input type="password" id="password" name="password" />
          </div>
          <div className="button-group">
            <button type="submit">Войти</button>
            <button type="button">Отмена</button>
          </div>
        </form>
        <div className="register-link">
          <a href="#register">Зарегистрироваться</a>
        </div>
      </div>
    </div>
  );
}

export default Autoriz;