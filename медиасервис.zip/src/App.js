import Header from '../src/header/header.js';
import {Routes, Route} from "react-router-dom";
import './App.css';
import News from './header/news.js';
import Vid from './header/Video.js';
import Fot from './header/foto.js';
import Prof from './header/prof.js';
import Autoriz from './header/autoriz.js';

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/news" Component={News}/>
        <Route path="/vid" Component={Vid}/>
        <Route path="/fot" Component={Fot}/>
        <Route path="/prof" Component={Prof}/>
        <Route path="/autoriz" Component={Autoriz}/>
      </Routes>
      <Header />
    </div>
  );
}

export default App;
