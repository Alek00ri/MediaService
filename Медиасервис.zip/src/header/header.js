import './header.css';
import React from 'react';
import {NavLink} from "react-router-dom";

function Header() {
  return (
    <div className='Header'>
        <NavLink className='butt' to="/news">Новости</NavLink>
        <NavLink className='butt' to="/vid">Видео</NavLink>
        <NavLink className='butt' to="/fot">Фото</NavLink>
        <NavLink className='butt' to="/prof">Профиль</NavLink>
      <div className='Header1'>
        <NavLink className='butt1' to="/autoriz">Авторизация</NavLink>
      </div>
    </div>
      
  );
}
export default Header;
