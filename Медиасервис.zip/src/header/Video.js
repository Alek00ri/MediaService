import './header.css';
import React from 'react';

function Vid() {
  return (
    <div className="Vid">
       

    </div>
      
  );
}

export default Vid;
