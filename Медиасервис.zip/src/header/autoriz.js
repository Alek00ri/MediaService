import './header.css';
import React from 'react';

function Autoriz() {
  return (
    <div className="Autoriz">
       

    </div>
      
  );
}

export default Autoriz;