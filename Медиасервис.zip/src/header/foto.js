import './header.css';
import React from 'react';

function Fot() {
  return (
    <div className="Fot">
       

    </div>
      
  );
}

export default Fot;
