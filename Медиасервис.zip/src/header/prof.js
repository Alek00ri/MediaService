import './header.css';
import React from 'react';

function Prof() {
  return (
    <div className="Prof">
       

    </div>
      
  );
}

export default Prof;