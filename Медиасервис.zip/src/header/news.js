import './news.css';
import React from 'react';
import ros from './../image/ros1.png';

function News() {
  return (
    <div className="News">
          <div className='divtext'>
            <img className='photo' src={ros} alt=""></img>
          <h1>Роскомнадзор заблокировал мессенджер Discord. Причина — систематическое нарушение требований российского законодательства. 
            Ранее в адрес сервиса было направлено множество требований удалить запрещенный контент, но их проигнорировали. Речь о детской порнографии, призывах к экстремизму, к суициду и употреблению наркотиков. Кроме того, в прошлом году суд назначил компании штраф в размере шести миллионов рублей за неудаление противоправной информации.
            Discord изначально создавался для общения геймеров, но позже им активно начали пользоваться преступники.</h1>
    </div>
            
      

        
        <div className='vidget'>
          <div className='a'>
          <img className='nov' src={ros} alt=""></img>
          <h1>Видео 1</h1>
          </div>

          <div className='a'>
          <img className='nov' src={ros} alt=""></img>
          <h1>Видео 2</h1>
          </div>

          <div className='a'>
          <img className='nov' src={ros} alt=""></img>
          <h1>Видео 3</h1>
          </div>

        </div>
    </div>
      
  );
}

export default News;
